package ru.tgbot.tgbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TgbotApplicationTests {

	@Test
	void contextLoads() {
	}

}
