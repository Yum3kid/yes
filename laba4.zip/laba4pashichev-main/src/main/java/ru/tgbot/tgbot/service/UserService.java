package ru.tgbot.tgbot.service;

public interface UserService {
    void registration(String username, String password);
}
