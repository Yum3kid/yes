package ru.tgbot.tgbot.exceptions;

public class UsernameAlreadyExistsException extends RuntimeException{
}
